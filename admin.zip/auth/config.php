<?php
const DB_HOST = 'localhost';
const DB_USER = 'arisu123';
const DB_PASS = 'arisu123';
const DB_NAME = 'wks';
?>